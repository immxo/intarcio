# intarcio
Корпусная мебель на заказ

## В проекте используется
1. react/redux 
2. express
2. mongodb
3. css modules
4. в верстке использую grid, flexbox

## Макет
https://www.figma.com/file/cbWxncBtfIMkhtagSCBOC8FV/%D0%98%D0%BD%D1%82%D0%B0%D1%80%D1%81%D0%B8%D1%8FV2
