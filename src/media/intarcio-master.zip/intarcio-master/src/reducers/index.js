const initialState = {
    user: 'Unknown User'
};
export default function userstate(state = initialState) {
    return state;
}