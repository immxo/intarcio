import React, { Component } from 'react'
import styles from '../styles/Slider.module.css'

class Slider extends Component {
    render() {
        return <section>
            <div className={styles.sliderImg}></div>
        </section>
    }
}

export default Slider
